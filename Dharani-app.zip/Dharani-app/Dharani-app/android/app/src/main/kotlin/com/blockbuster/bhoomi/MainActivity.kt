package com.blockbuster.bhoomi

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
